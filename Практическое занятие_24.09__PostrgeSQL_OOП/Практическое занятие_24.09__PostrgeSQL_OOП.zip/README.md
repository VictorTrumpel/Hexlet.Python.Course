1. По игре UNO добавил подсчет очков
2. почта на курсе hexlet - victor.trumpel@gmail.com
